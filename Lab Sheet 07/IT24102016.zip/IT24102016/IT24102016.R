 setwd("C:\\Users\\lisha\\Desktop\\IT24102016")
#part 1
 #P(X<=10)
 punif(10,min=0,max=30,lower.tail=TRUE)

1- punif(20, min =0, max=30,lower.tail = TRUE)

 punif(20,min =0,max=30,lower.tail =FALSE)

 #part 1
   #P(X<=3)
   pexp(3, rate=0.5, lower.tail=TRUE)
    #part 2
      #P (x > 4) = 1 - P(x <= 4)
      1- pexp(4, rate=0.5,lower.tail= TRUE)
   
      pexp(4, rate = 0.5, lower.tail = FALSE)
      
      # Part 3
      # P(2 < x < 4) = P(X ≤ 4) - P(X ≤ 2)
      pexp(4, rate = 0.5, lower.tail = TRUE) - pexp(2, rate = 0.5, lower.tail = TRUE)
      
                             
      # P(x ≥ 37.9) = 1 - P(x < 37.9)
      1 - pnorm(37.9, mean = 36.8, sd = 0.4, lower.tail = TRUE)
      
                             
      # P(36.4 < x < 36.9) = P(x ≤ 36.9) - P(x ≤ 36.4)
      pnorm(36.9, mean = 36.8, sd = 0.4, lower.tail = TRUE) - pnorm(36.4, mean = 36.8, sd = 0.4, lower.tail = TRUE)
    
      
      
      # Part 3
      # P(x < b) = 1.2% = 0.012
      qnorm(0.012, mean = 36.8, sd = 0.4, lower.tail = TRUE)
      
     
      # Part 4
      # P(x > b) = 1% = 0.01
      qnorm(0.01, mean = 36.8, sd = 0.4, lower.tail = FALSE)
  
      
      
      
      
      
      
      
      # Uniform Distribution
      # a = 0, b = 40 minutes
      # P(10 ≤ x ≤ 25) = P(x ≤ 25) - P(x ≤ 10)
      punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)
      
      # P(X ≤ 2) for exponential distribution with rate = 1/3
      pexp(2, rate = 1/3, lower.tail = TRUE)
      
      # P(x > 130) = 1 - P(x ≤ 130)
      1 - pnorm(130, mean = 100, sd = 15, lower.tail = TRUE)
      
      
      # Find the value b such that P(x ≤ b) = 0.95
      qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)
      
         
         
                                