# Set the working directory
setwd("C:\\Users\\lisha\\Desktop\\Lab8")
getwd()

# Importing the data set
data <- read.table("Exercise - LaptopsWeights.txt", header =  TRUE)

colnames(data) <- c("Weight")
attach(data)

# part - 1 
# Calculate the population mean and population standard deviation of the laptop bag weights.

popmean <- mean(Weight)
popsd <- sd(Weight) 

popmean
popsd

# part - 2
# Draw 25 random samples of size 6 (with replacement) and calculate the sample mean and sample standard deviation for each sample.
samples <- matrix(0, nrow=25, ncol=6)
sample_means <- numeric(25)
sample_sds <- numeric(25)

for(i in 1:25) {
  samples[i,] <- sample(Weight, 6, replace=TRUE)
  sample_means[i] <- mean(samples[i,])
  sample_sds[i] <- sd(samples[i,])
}

# Display the sample means and standard deviations 
for(i in 1:25) {
  cat("Sample", i, "- Mean:", sample_means[i], "SD:", sample_sds[i], "\n")
}

# part - 3. 
# Calculate the mean and standard deviation of the 25 sample means.
samplemean_mean <- mean(sample_means)
samplemean_sd <- sd(sample_means)

samplemean_mean
samplemean_sd
