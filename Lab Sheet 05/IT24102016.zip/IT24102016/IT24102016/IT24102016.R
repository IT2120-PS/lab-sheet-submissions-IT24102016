
setwd("C:\\Users\\lisha\\Desktop\\IT24102016\\IT24102016")
getwd()
##exercise


# Step 1: Import dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Check the first few rows
head(Delivery_Times)

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = FALSE)
colnames(Delivery_Times) <- c("Time")

str(Delivery_Times)
# Convert column to numeric
Delivery_Times$Time <- as.numeric(Delivery_Times$Time)
Delivery_Times$Time <- as.numeric(trimws(Delivery_Times$Time))
str(Delivery_Times)
hist(Delivery_Times$Time,
     breaks = seq(20, 70, length.out = 10),
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency",
     col = "lightblue", border = "black")

#  Draw histogram
hist(Delivery_Times$Time,
     breaks = seq(20, 70, length.out = 10),  # 9 intervals
     right = FALSE,                          # right-open intervals
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency",
     col = "lightblue", border = "black")



# Create frequency table
breaks <- seq(20, 70, length.out = 10)
freq_table <- hist(Delivery_Times$Time, breaks = breaks, plot = FALSE)

# Cumulative frequency
cum_freq <- cumsum(freq_table$counts)

# Plot ogive
plot(breaks[-1], cum_freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time",
     ylab = "Cumulative Frequency",
     col = "red", pch = 16)


